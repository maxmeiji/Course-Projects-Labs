#include <iostream>
#include <algorithm>
#include <string>
#include <vector>
#include <fstream>

#include<iomanip> //add 

using namespace std;

struct info {
	int height;
	int weight;

	// don't change this
	bool operator<(const info& other) const {
		return height < other.height;
	}
};

//TODO: implement three comparsion function 
//example: 
//bool functionName(const dataType& p1, const dataType& p2) {
//	return p1 > p2;
//}

//1.implement compare by height here
bool compareheight(const pair<string, info> & p1, const pair<string, info> & p2) 
{	

	info i=p1.second;
	info j=p2.second;

	return i.height<j.height;
}

//2.implement compare by weight here
bool compareweight(const pair<string, info> & p1, const pair<string, info> & p2) 
{	

	info i=p1.second;
	info j=p2.second;

	return i.weight<j.weight;
}

//3.implement compare by height and weight here
bool comparehandw(const pair<string, info> & p1, const pair<string, info> & p2) 
{	

	info i=p1.second;
	info j=p2.second;
	if(i.height==j.height)
		return i.weight<j.weight;
	else
		return i.height<j.height;
}

class Map
{
public:
	Map()
	{
		people.clear();
	}

	void readFile() {
		fstream file;
		file.open("test.txt", ios::in);
		int cmdNum;
		file >> cmdNum;

		while (cmdNum--) {
			char cmd;
			file >> cmd;
			switch (cmd) {
				case 'a':
				{
					string name;
					file >> name;
					info ii;
					file >> ii.height >> ii.weight;
					add(name, ii);
					break;
				}
				case 'f':
				{
					string name;
					file >> name;
					find(name);
					break;
				}
				case 'e':
				{
					string name;
					file >> name;
					erase(name);
					break;
				}
			}
		}

		file.close();
	}

	void add(string name, info& _info) {
		//TODO: implement add function add new data into the map(vector<pair<...>>)
		//If the name is already in the map, override his/her data
		vector<pair<string, info> >::iterator iter ;
		int counter=0;
		
		for(iter=people.begin(); iter!=people.end(); iter++)
		{
			if(name==iter->first)
			{
				info i=iter->second;
				iter->second=_info;
				info j=iter->second;
				cout<<name<<"'s h:"<<i.height<<" and w:"<<i.weight<<" is changed to h:"<<j.height<<" and w:"<<j.weight<<endl;
				counter++;
			}
		}
		if(counter==0)
		{
			people.push_back(make_pair(name, _info));
		}
		
		
	}

	void find(string name) {
		//TODO: implement find function to get the information of the given name if the name exist
		//otherwise, print "name is not found"
		//you must use iterator to implement
		vector<pair<string, info> >::iterator iter ;
		int counter=0;
		for(iter=people.begin(); iter!=people.end(); iter++)
		{

			if(name==iter->first)
			{
				info i=iter->second;
				cout<<name<<" is found!"<<" h:"<<i.height<<" and w:"<<i.weight<<endl;	
				counter++;
			}
		}
		if(counter==0)
		{
			cout<<name<<" is not found!"<<endl;	
		}
		
	}

	void erase(string name) {
		//TODO: implement erase function to delete the element of the given name if the name exist
		//otherwise, print "name is not found"
		//you must use iterator to implement
		vector<pair<string, info> >::iterator iter ;
		int counter=0;
		for(iter=people.begin(); iter!=people.end(); iter++)
		{

			if(name==iter->first)
			{
				iter=people.erase(iter);
				cout<<name<<" is erased!"<<endl;	
				counter++;
			}
		}
		if(counter==0)
		{
			cout<<name<<" is not found!"<<endl;	
		}
		
	}
		

	void sortByName() {
		//TODO: call sort() function (default one)
		sort(people.begin(), people.end());
	}

	void sortByInfo(const char* type) {

		if (type == "H") {
			//TODO: call sort() function and compare by height
			sort(people.begin(), people.end(), compareheight);
		}
		else if (type == "W") {
			//TODO: call sort() function and compare by weight
			sort(people.begin(), people.end(), compareweight);
		}
		else if (type == "HW") {
			//TODO: call sort() function and compare by height and weight
			sort(people.begin(), people.end(), comparehandw);
		}
	}

	void write(fstream& file) {
		//TODO: Write all elements in the map to the file
		//you must use iterator to implement
		vector<pair<string, info> >::iterator iter ;
		for(iter=people.begin(); iter!= people.end(); iter++)
		{
			info i=iter->second;
			string a=iter->first+":";
			file<<left<<setw(8)<<a<<i.height<<", "<<i.weight<<endl;
		}
		file<<endl;
	
	}

	void writeFile() {
		fstream file;
		file.open("lab7.txt", ios::out);

		file << "Sort By Name\n";
		sortByName();
		write(file);
		file << "Sort By Height\n";
		sortByInfo("H");
		write(file);
		file << "Sort By Weight\n";
		sortByInfo("W");
		write(file);
		file << "Sort By Height&Weight\n";
		sortByInfo("HW");
		write(file);

		cout << "File lab7.txt saved!\n";
		file.close();
	}

private:
	vector<pair<string, info> > people;
};

int main() {
	Map myMap;

	myMap.readFile();
	myMap.writeFile();

	system("pause");
	return 0;
}
