#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

class Roll_Call_System {

private:
	vector<string> studentNames{};
	vector<string> pickedStudentNames{};
	int seed;
	int a;
	int c;
	int m;
	
	
	int count=0;
	int count2=0;

public:
	fstream fin;

	void OpenFile() {
		//TODO: open the file
		
		
		fin.open("student.txt");
		cout<<"Filename: student.txt"<<endl;
		if(!fin)
		{
			cerr<<"ERROR! "<<endl;
			exit(1);
		}
	 
	}

	void AddNames() {
		//TODO : add name to studentName vector
		int n;  //number of students
		string name;
		fin>>n;
		
		for(int i=0; i<n; i++)
		{
			fin>>name;
			studentNames.push_back(name);
		}
	}

	int GenerateRandomNumber(int n) {
		//TODO: implement linear random number generator
		
		if(n<=0)
		{
			return seed;
		}
		else
		{
			return (a*GenerateRandomNumber(n-1)+c)%m;
		}	
	}

	void PickNames() {
		//TODO: randomly pick name form studentName vector
		//		and add them to pickedStudentName vector
		
		int time, th;                // time->pick_student_num, th->the th student
		
		string r;                    //memorize
		fin>>seed>>a>>c>>m;
		fin>>time;
 
		for(int i=0; i<time; i++)
		{
			th=GenerateRandomNumber(i+1);

			pickedStudentNames.push_back(studentNames[th]);

		}
	
	}

	void PrintPickedStudentNames() {
		//TODO: print all picked name form studentName vector
		cout<<"Picked Name: "<<endl;
		for(int i=count; i<pickedStudentNames.size(); i++)
		{
			cout<<pickedStudentNames[i]<<endl;
			count++;
		}

	}

	void CaculateAlphabets() {
		//TODO: calculate how many diffetent alphabets are used and print it
		
		
		string a="";

		int counter;


		for(int i=count2; i<pickedStudentNames.size(); i++)
		{
		a+=pickedStudentNames[i];
		count2++;
		}
		counter=0;
		
		for(int i=0; i<a.size(); i++)
		{
			for(int j=i+1; j<a.size(); j++)
			{
				
				int b=static_cast<int>(a[i]);
				int c=static_cast<int>(a[j]);
				
				if(b!=0)
				{
					if(b==c || b-c==32 || c-b==32 )
					{	

						a[j]=0;
						counter++;
					}
				}	
			} 	
		}
		
		cout<<"Total alphabets: "<<a.size()-counter<<endl;
		cout<<"\n";
	}
};

int main() {
	
	Roll_Call_System rcs;
	rcs.OpenFile();
	rcs.AddNames();

	int times;
	rcs.fin >> times;
	
	while (times--) {
		rcs.PickNames();
		rcs.PrintPickedStudentNames();
		rcs.CaculateAlphabets();
	}
	
	system("PAUSE");
	return 0;

}
