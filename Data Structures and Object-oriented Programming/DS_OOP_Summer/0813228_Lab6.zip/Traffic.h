#ifndef TRAFFIC_H
#define TRAFFIC_H
#include "Student.h"
#include<iostream>
using namespace std;

class Traffic:public Student{
	
	public:
		Traffic(string id, int score, int money, float background):Student(id, score, money, background){}
		
		void ShowSchool()
		{
			cout<<"Student "<<id<<" is Traffic student"<<endl;
			
		}		
};

#endif
