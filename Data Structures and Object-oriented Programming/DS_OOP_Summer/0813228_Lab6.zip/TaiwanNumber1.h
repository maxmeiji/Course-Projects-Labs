#ifndef TAIWANNUMBER1_H
#define TAIWANNUMBER1_H
#include "Student.h"
#include<iostream>
using namespace std;

class TaiwanNumber1:public Student{
	
	public:
		TaiwanNumber1(string id, int score, int money, float background):Student(id, score, money, background){}
		
		void ShowSchool()
		{
			cout<<"Student "<<id<<" is TaiwanNumber1 student"<<endl;
			
		}		
};

#endif
