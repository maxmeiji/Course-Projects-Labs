#ifndef STUDENT_H
#define STUDENT_H
#include<iostream>
using namespace std;

class Student{
	
	public:
		Student() //constructor with no constructor
		{
		}
		
		Student(string id, int score, int money, float background)
		{
			this->id=id;
			this->score=score;
			this->money=money;
			this->background=background;
		}
		
		void printAllInfo()
		{
			cout<<"ID : "<<id<<endl;
			cout<<"Score : "<<score<<endl;
			cout<<"Money : "<<money<<endl;
			cout<<"Background : "<<background<<endl;
		}
		
		virtual void ShowSchool(){}
		
		string getID()
		{
			return id;
		 } 
		 
	protected:
		
		string id;
		int score;
		int money;
		float background; 
};
#endif

