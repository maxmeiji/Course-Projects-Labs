#ifndef BIGLEAF_H
#define BIGLEAF_H
#include "Student.h"
#include<iostream>
using namespace std;

class BigLeaf:public Student{
	
	public:
		BigLeaf(string id, int score, int money, float background):Student(id, score, money, background){}
		
		void ShowSchool()
		{
			cout<<"Student "<<id<<" is BigLeaf student"<<endl;
			
		}		
};

#endif
