#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

class matrix
{
public:
	vector<vector<int> > M;
	vector<vector<int> > adj;
	vector<vector<int> > update;
	
	matrix()
	{
		//TO_DO: Initialize a matrix of size 3 * 3
		for(int i=0; i<3; i++)
		{
			for(int j=0; j<3; j++)
			{
				M[i][j]=0;
			}
		}		
	}
	
	matrix(vector<vector<int> >& m)
	{
		M = m;
	}
	void multiple(vector<vector<int> >& a, vector<vector<int> >& b)
	{
		
		for(int i=0; i<3; i++)
		{	
			vector<int>c;
			for(int j=0; j<3; j++)
			{	
				int multiple=0;
				
				for(int k=0; k<3; k++)
				{
					multiple+=a[i][k]*b[k][j];	
				}
				
				c.push_back(multiple);
	
			}
			update.push_back(c);
		}
		
	}
	
	int cofactor(vector<vector<int> >& v, int x, int y)
	{
		int a = 0;
		int b = 0;
		vector<int> array;

		for (int i = 0; i<3; i++)
		{			
			for (int j = 0; j<3; j++)
			{
				if (i!=x && j!=y)
				{
					array.push_back(v[i][j]);
					b++;
					if (b==1)
					{
						b = 0;
						a++;
					}
				}
			}
		}
		int c=array[0]*array[3]-array[1]*array[2];
		return c;
	}
	
	void adjoint()
	{
		int sign=1;
		vector<vector<int> > replace;
		for(int i=0; i<3; i++)
		{	
			vector<int>c;
			for(int j=0; j<3; j++)
			{
				int calculate, val;

				calculate=cofactor(M, i, j);

				val=sign*calculate;
				c.push_back(val);

				sign=-sign;
			}
			adj.push_back(c);
			replace.push_back(c);
		}
		
	for(int i=0; i<3; i++)
		{
			for(int j=0; j<3; j++)
			{
				if(i!=j)
					adj[i][j]=replace[j][i];
			}
		}		
	}

	
	void determinant()
	{
		adjoint();
		multiple(M, adj);
		cout<<"the determinant of matrix M is: "<<update[0][0]<<endl;
	
	}
	// TO_DO: Implement a function to multiply two matrices.
	
	// TO_DO: Implement a function to calculate the classic adjoint matrix.
	
	// TO_DO: Implement a function to calculate the determinant.
};

int main() 
{
	fstream fin;
	
	fin.open("data.txt", ios::in);
	if (!fin) {
		cout << "File is not opened" << endl;
		exit(0);
		system("pause");
	}
	
	int n;
	fin >> n;
	
	
	int c;
	
	
	for(int i=0; i<n; i++) {
		////////////////////////
		// TO_DO: read the input and call the functions you've implemented to generate the output
		
		vector<vector<int> >value;
		for(int i=0; i<3; i++)
		{
			vector<int>input;
			for(int j=0; j<3; j++)
			{	
				
				fin>>c;
				input.push_back(c);
			}
			value.push_back(input);
		}	
		matrix s(value);
		s.determinant();
		////////////////////////
	}
	
	system("pause");
	return 0;
}
