#include <iostream>
#include<fstream>
#include <vector>
using namespace std;


void swap(int &p1, int &p2){
    int temp = p1;
    p1 = p2;
    p2 = temp;
}

void MaxHeapify(vector<int> &array, int root, int length)
{

    int left = 2*root;    
    int right = 2*root + 1;
    int largest;              

    if (left <= length && array[left] > array[root])
        largest = left;
    else
        largest = root;

    if (right <= length && array[right] > array[largest])
        largest = right;

    if (largest != root) {                        
        swap(array[largest], array[root]);        
        MaxHeapify(array, largest, length);        
    }
}

void BuildMaxHeap(vector<int> &array){

    int size=array.size()/2;
	for (int i =size; i >= 1 ; i--) 
	{
        MaxHeapify(array, i, array.size()-1);     
    }
}

void HeapSort(vector<int> &array){

    array.insert(array.begin(), 0);                     

    BuildMaxHeap(array);                                

    int size =array.size() -1;                    
    for (int i = array.size() -1; i >= 2; i--) 
	{
        swap(array[1], array[i]);                       
        size--;
        MaxHeapify(array, 1, size);                     
	}
}

void PrintArray(vector<int> &array){
    for (int i=1; i<array.size(); i++) 
	{
	    cout << array[i] << " ";
    }
}

int main() {
	
	int n;
	int element;
	vector<int>arr;
	
	fstream afile;
	afile.open("input.txt");
	
	afile>>n;
	while(n--)
	{
		afile>>element;
		arr.push_back(element);
	}
    HeapSort(arr);
    PrintArray(arr);
}
