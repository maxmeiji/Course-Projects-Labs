#include"LinkedList.h"

LinkedList::LinkedList()
{
	head = NULL;
}

LinkedList::~LinkedList()
{
	Clear();
}


void LinkedList::Push_back(int x)
{
	//TODO: add a new node to the back of the list with value x
	Node *newnode=new Node(x);
	Node* curr=head;
	if(head==NULL)
	{
		head=newnode;
		return;
	} 
	
	while(curr->next!=0)
	{
		curr=curr->next;
	}
	curr->next=newnode;
}

void LinkedList::Push_front(int x)
{
	//TODO: add a new node to the front of the list with value x
	Node *newnode=new Node(x);
	if(head==0)
	{
		head=newnode;
		return;
	}
	newnode->next=head;
	head=newnode;
}

void LinkedList::Insert(int index, int x)
{
	//TODO: add a new node at position "index" of the list with value x
	if(index==0)
	{
		Push_front(x);
		return;
	}

	Node *newnode=new Node(x);
	Node *curr=head;
	Node *temp=head;
	
	while(index-1!=0)
	{
		curr=curr->next;
		index--;
	}
	
	temp=curr->next;
	curr->next=newnode;
	newnode->next=temp;
	
}

void LinkedList::Delete(int index)
{
	//TODO: delete the node at position "index"
	if(index==0)
	{
		head=head->next;
		return;
	}

	Node *curr=head;
	Node *temp=head;
	
	while(index-1!=0)
	{
		curr=curr->next;
		index--;
	}
	
	temp=curr->next;
	curr->next=temp->next;
	
	
}

void LinkedList::Reverse()
{
	//TODO: reverse all elements in the list
	Node *curr=head;
	Node *pre=0;
	Node *temp=head;

	while(curr!=0)
	{
		temp=curr->next;
		curr->next=pre;
		pre=curr;
		curr=temp;
		
	}
	head=pre;

}

void LinkedList::Print()
{
	//TODO: print out all elements in the list
	if(head==0)
	{
		cout<<"The list is empty"<<endl;
		return;
	}
	for(Node* curr=head; curr!=0; curr=curr->next)
	{
		cout<<curr->value<<" ";
	}
	cout<<endl;
}

void LinkedList::Clear() 
{
	//TODO: delete all elements in the list
	head=0;
}
