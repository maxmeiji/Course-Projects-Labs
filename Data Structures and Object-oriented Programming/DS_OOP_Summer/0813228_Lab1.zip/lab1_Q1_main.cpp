#include<iostream>
#include"lab1_Q1.h"
#include"lab1_Q1.cpp"

using namespace std;

int main()
{
	

	int n;
	double a,b,c;
	char command;
	double d, e, f;	
		
	cin>>n;
	while(n--)
	{
	cin>>command>>a>>b>>c;
	if(command=='+')
		cin>>d>>e>>f;

	QUADRATIC t(a,b,c);
	QUADRATIC q(d,e,f);
	
	switch(command)
	{
		case 'p':
			t.print();
			break;
		
		case '+':

			t.add(q);
			break;
		
		case 'd':
			t.discriminant();
			break;
		
		default:
			cout<<"wrong input!"<<endl;
			break;
	}

	}
	
	system("PAUSE");
	return 0;
}
