#include "lab1_Q1.h"
#include <iostream>
#include <string>
#include <cmath>

using namespace std;

void QUADRATIC::print()
{	
	char signa, signb;
	if(b>=0)
		signa='+';
	else
		signa=' ';
		
	if(c>=0)
		signb='+';
	else
		signb=' ';
			
	cout<<a<<"x^2"<<signa<<b<<"x"<<signb<<c<<endl;
}

void QUADRATIC::add(QUADRATIC q)
{
	a=a+q.a;
	b=b+q.b;
	c=c+q.c;
	print();
}

void QUADRATIC::discriminant()
{
	double D,q1,q2; 
	D=pow(b,2)-4*a*c;
	if(D>0)
	{
		q1=(-b+sqrt(D))/double(2*a);
		q2=(-b-sqrt(D))/double(2*a);
		cout<<"There are two roots:"<<q1<<", "<<q2<<endl;;
	}
	else if(D==0)
	{
		q1=(-b)/2*a;
		cout<<"There is a double root:"<<q1<<endl;
	}
	else
	{
		q1=(sqrt(-D))/(2*a);
		q2=(sqrt(-D))/(2*a);
		cout<<"There are two complex roots:"<<double(-b)/(2*a)<<"+"<<q1<<"i"<<", "<<double(-b)/(2*a)<<"-"<<q2<<"i"<<endl;
	}
			
}
